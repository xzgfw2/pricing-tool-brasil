def calculate_diff_pp(value, other_value):
    return (float(other_value) - float(value)) * 100