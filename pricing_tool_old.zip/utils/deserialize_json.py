import json

def deserialize_json(data):
    return json.loads(data)
