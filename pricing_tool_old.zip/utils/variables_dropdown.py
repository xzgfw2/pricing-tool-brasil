VARIABLES_DROPDOWN = [
    "Ano frota",
    "Aplicações",
    "Elasticidade",
    "Estoque",
    "Frota",
    "Marca",
    "Price index",
]
